/**
 * SOLAR Platform — Database Layer
 * 
 * Sprint 3: Production-ready with Prisma support
 * 
 * This module provides:
 * - In-memory fallback for development (no DB required)
 * - Prisma integration for production
 * 
 * To switch to Prisma:
 * 1. Set DATABASE_URL in .env
 * 2. Run: pnpm db:generate && pnpm db:push
 * 3. Uncomment Prisma imports below
 */

import type { SystemRole, TenantRole, SessionUser } from './auth';
import { hashPassword, generateSessionToken, getSessionExpiry, generateSlug } from './auth';

// ============================================================
// PRISMA CLIENT (uncomment for production)
// ============================================================
// import { PrismaClient } from '@prisma/client';
// const prisma = new PrismaClient();

// ============================================================
// TYPES
// ============================================================

interface User {
  id: string;
  email: string;
  password: string;
  name: string | null;
  systemRole: SystemRole;
  createdAt: Date;
}

interface Tenant {
  id: string;
  slug: string;
  name: string;
  status: 'PENDING' | 'ACTIVE' | 'SUSPENDED' | 'CLOSED';
  createdAt: Date;
}

interface Membership {
  id: string;
  userId: string;
  tenantId: string;
  role: TenantRole;
  createdAt: Date;
}

interface Session {
  id: string;
  token: string;
  userId: string;
  expiresAt: Date;
  createdAt: Date;
}

// ============================================================
// IN-MEMORY STORAGE (Development fallback)
// ============================================================

const users: Map<string, User> = new Map();
const tenants: Map<string, Tenant> = new Map();
const memberships: Map<string, Membership> = new Map();
const sessions: Map<string, Session> = new Map();

// Initialize with demo data
async function initDemoData(): Promise<void> {
  // Skip if already initialized
  if (users.size > 0) return;

  // Create demo admin user
  const adminPassword = await hashPassword('Admin123!');
  const adminUser: User = {
    id: 'user_admin',
    email: 'admin@solar.ch',
    password: adminPassword,
    name: 'SOLAR Admin',
    systemRole: 'SOLAR_ADMIN',
    createdAt: new Date(),
  };
  users.set(adminUser.id, adminUser);
  
  // Create demo tenant
  const demoTenant: Tenant = {
    id: 'tenant_demo',
    slug: 'acme-gmbh',
    name: 'ACME GmbH',
    status: 'ACTIVE',
    createdAt: new Date(),
  };
  tenants.set(demoTenant.id, demoTenant);
  
  // Create demo client user
  const clientPassword = await hashPassword('Client123!');
  const clientUser: User = {
    id: 'user_client',
    email: 'client@acme.ch',
    password: clientPassword,
    name: 'Max Mustermann',
    systemRole: 'USER',
    createdAt: new Date(),
  };
  users.set(clientUser.id, clientUser);
  
  // Create membership
  const membership: Membership = {
    id: 'membership_1',
    userId: clientUser.id,
    tenantId: demoTenant.id,
    role: 'OWNER',
    createdAt: new Date(),
  };
  memberships.set(membership.id, membership);
}

// Initialize on module load
initDemoData().catch(console.error);

// ============================================================
// USER OPERATIONS
// ============================================================

export async function findUserByEmail(email: string): Promise<User | null> {
  // FIX: Use Array.from() for ES5 compatibility
  const userList = Array.from(users.values());
  for (let i = 0; i < userList.length; i++) {
    const user = userList[i];
    if (user.email.toLowerCase() === email.toLowerCase()) {
      return user;
    }
  }
  return null;
}

export async function findUserById(id: string): Promise<User | null> {
  return users.get(id) ?? null;
}

export async function createUser(data: {
  email: string;
  password: string;
  name: string;
  systemRole?: SystemRole;
}): Promise<User> {
  const hashedPassword = await hashPassword(data.password);
  const user: User = {
    id: `user_${Date.now()}`,
    email: data.email.toLowerCase(),
    password: hashedPassword,
    name: data.name,
    systemRole: data.systemRole ?? 'USER',
    createdAt: new Date(),
  };
  users.set(user.id, user);
  return user;
}

// ============================================================
// TENANT OPERATIONS
// ============================================================

export async function findTenantBySlug(slug: string): Promise<Tenant | null> {
  // FIX: Use Array.from() for ES5 compatibility
  const tenantList = Array.from(tenants.values());
  for (let i = 0; i < tenantList.length; i++) {
    const tenant = tenantList[i];
    if (tenant.slug === slug) {
      return tenant;
    }
  }
  return null;
}

export async function createTenant(data: {
  name: string;
  slug?: string;
}): Promise<Tenant> {
  const slug = data.slug ?? generateSlug(data.name);
  
  // Ensure unique slug
  let finalSlug = slug;
  let counter = 1;
  while (await findTenantBySlug(finalSlug)) {
    finalSlug = `${slug}-${counter}`;
    counter++;
  }
  
  const tenant: Tenant = {
    id: `tenant_${Date.now()}`,
    slug: finalSlug,
    name: data.name,
    status: 'ACTIVE',
    createdAt: new Date(),
  };
  tenants.set(tenant.id, tenant);
  return tenant;
}

// ============================================================
// MEMBERSHIP OPERATIONS
// ============================================================

export async function getUserMemberships(userId: string): Promise<Array<{
  tenantId: string;
  tenantSlug: string;
  role: TenantRole;
}>> {
  const result: Array<{ tenantId: string; tenantSlug: string; role: TenantRole }> = [];
  
  // FIX: Use Array.from() for ES5 compatibility
  const membershipList = Array.from(memberships.values());
  for (let i = 0; i < membershipList.length; i++) {
    const membership = membershipList[i];
    if (membership.userId === userId) {
      const tenant = tenants.get(membership.tenantId);
      if (tenant) {
        result.push({
          tenantId: membership.tenantId,
          tenantSlug: tenant.slug,
          role: membership.role,
        });
      }
    }
  }
  
  return result;
}

export async function createMembership(data: {
  userId: string;
  tenantId: string;
  role: TenantRole;
}): Promise<Membership> {
  const membership: Membership = {
    id: `membership_${Date.now()}`,
    userId: data.userId,
    tenantId: data.tenantId,
    role: data.role,
    createdAt: new Date(),
  };
  memberships.set(membership.id, membership);
  return membership;
}

// ============================================================
// SESSION OPERATIONS
// ============================================================

export async function createSession(userId: string): Promise<Session> {
  const session: Session = {
    id: `session_${Date.now()}`,
    token: generateSessionToken(),
    userId,
    expiresAt: getSessionExpiry(),
    createdAt: new Date(),
  };
  sessions.set(session.token, session);
  return session;
}

export async function findSessionByToken(token: string): Promise<Session | null> {
  const session = sessions.get(token);
  if (!session) return null;
  
  // Check expiration
  if (session.expiresAt < new Date()) {
    sessions.delete(token);
    return null;
  }
  
  return session;
}

export async function deleteSession(token: string): Promise<void> {
  sessions.delete(token);
}

export async function getSessionUser(token: string): Promise<SessionUser | null> {
  const session = await findSessionByToken(token);
  if (!session) return null;
  
  const user = await findUserById(session.userId);
  if (!user) return null;
  
  const userMemberships = await getUserMemberships(user.id);
  
  return {
    id: user.id,
    email: user.email,
    name: user.name,
    systemRole: user.systemRole,
    memberships: userMemberships,
  };
}

// ============================================================
// CLEANUP (for session expiry)
// ============================================================

export async function cleanupExpiredSessions(): Promise<number> {
  const now = new Date();
  let cleaned = 0;
  
  // FIX: Use Array.from() for ES5 compatibility
  const sessionList = Array.from(sessions.entries());
  for (let i = 0; i < sessionList.length; i++) {
    const [token, session] = sessionList[i];
    if (session.expiresAt < now) {
      sessions.delete(token);
      cleaned++;
    }
  }
  
  return cleaned;
}

// ============================================================
// EXPORT PRISMA-LIKE INTERFACE
// ============================================================

export const db = {
  user: {
    findByEmail: findUserByEmail,
    findById: findUserById,
    create: createUser,
  },
  tenant: {
    findBySlug: findTenantBySlug,
    create: createTenant,
  },
  membership: {
    getUserMemberships,
    create: createMembership,
  },
  session: {
    create: createSession,
    findByToken: findSessionByToken,
    delete: deleteSession,
    getUser: getSessionUser,
    cleanup: cleanupExpiredSessions,
  },
};
